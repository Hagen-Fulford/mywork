from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash


class Show:
    db_name = "users_belt_schema_three" #! update this to connect to the correct database 
    def __init__(self,show_data):   #! release_date your you variable is correct in all your class/static methods 
        self.id = show_data['id']
        self.title = show_data['title']
        self.network = show_data['network']                #! release_date sure all of the keys are spelled and puncutiaon is the same
        self.release_date = show_data['release_date']                    #! as whats in the db, on the htmls templates 
        self.description = show_data['description']
        self.user_id = show_data['user_id']  
        self.user = []  #* placeholder holder holding many movies   the [] would be replaced with none if you are linking only one user to one show 



    @classmethod 
    def save(cls,data):
        query = "INSERT INTO shows(title,network,release_date,description,user_id) VALUES (%(title)s,%(network)s,%(release_date)s,%(description)s,%(user_id)s);"
        return connectToMySQL(cls.db_name).query_db(query,data)



    @classmethod
    def get_all(cls):
        query = "SELECT * FROM shows;"
        results =  connectToMySQL(cls.db_name).query_db(query)
        all_shows = []
        for row in results:
            print(row['title'])
            all_shows.append(cls(row) )
        return all_shows


    @classmethod
    def get_one(cls,data):
        query = "SELECT * FROM shows WHERE id = %(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        return cls( results[0] )


    @classmethod
    def get_one_show_with_user(cls,data):
        query = "SELECT * FROM shows LEFT JOIN users ON shows.user_id = users.id WHERE shows.id =%(id)s;"
        results = connectToMySQL(cls.db_name).query_db(query,data)
        return cls( results[0] )


    @classmethod
    def update(cls, data):
        query = "UPDATE shows SET title=%(title)s,name=%(network)s,release_date=%(release_date)s, description=%(description)s,updated_at=NOW() WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)
    
    @classmethod
    def destroy(cls,data):
        query = "DELETE FROM shows WHERE id = %(id)s;"
        return connectToMySQL(cls.db_name).query_db(query,data)


    @staticmethod
    def validate_show(show):
        is_valid = True
        if len(show['title']) < 3:
            is_valid = False
            flash("Title must be at least 3 characters","show")
        if len(show['network']) < 3:
            is_valid = False
            flash("Network must be at least 3 characters","show")
        if len(show['release_date']) < 3:
            is_valid = False
            flash("Release date must be at least 3 characters","show")
        if len(show['description']) < 4:                   
            is_valid = False
            flash("Description must be at least 4 characters","show")
        return is_valid 


